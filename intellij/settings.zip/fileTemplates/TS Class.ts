/**
 * ${NAME} Class description
 */
export class ${NAME} implements I${NAME} {

}
