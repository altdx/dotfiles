import React from 'react';
import { I${NAME} } from './types';
import './${NAME}.style';

/**
 * Description of ${NAME}
 */
export const ${NAME}: React.FC<I${NAME}> = ({ name = '' }) => {
  return <div>${NAME}.tsx</div>;
};
