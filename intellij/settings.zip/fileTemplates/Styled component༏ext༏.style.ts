import styled from 'styled-components/macro';

export const ${NAME}Styled = styled.div`

`;
