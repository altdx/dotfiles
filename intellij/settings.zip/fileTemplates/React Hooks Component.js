import React, { Fragment, useState, useEffect } from 'react';
import PropTypes from 'prop-types';

const ${NAME} = ({ myProp }) => {
  const [data, setData] = useState(null);

  useEffect((name) => {

  });

  return (
    <>
      ${NAME} {myProp}!
    </>
  );
};

${NAME}.defaultProps = {
  myProp: '',
};

${NAME}.propTypes = {
  myProp: PropTypes.string.isRequired,
};

export default ${NAME};
