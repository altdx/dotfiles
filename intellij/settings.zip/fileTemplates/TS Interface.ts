/**
 * I${NAME} description
 */
export interface I${NAME} {
  name: string;
}
