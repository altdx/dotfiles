/**
 * ${NAME} Class description
 * 
 * @class ${NAME}
 */
export class ${NAME} {
  
}
