import { ${NAME} } from '../src/${NAME}';

beforeEach(() => {
  // initialize
});

afterEach(() => {
  // clear
});

describe('${NAME}', () => {
  it('should test description', () => {
    expect(true).toBe(true);
  });
});
