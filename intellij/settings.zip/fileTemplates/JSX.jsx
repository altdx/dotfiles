import React, { useState, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';

/**
 * Description
 */
const ${NAME} = (props) => {
    const [count, setCount] = useState(0);
    
    return (
        <div>
            Hello ${NAME}
        </div>
    );
};


${NAME}.defaultProps = {
    name: '',
};

${NAME}.propTypes = {
    /**
     * Description
     */
    name: PropTypes.string,
};

export default ${NAME};